const mongoose=require("mongoose");
const registerSchema=mongoose.Schema({
    
    user:String,
    email:String,
    password:String
   
})

const registerModel=mongoose.model("registers",registerSchema)

module.exports=registerModel;