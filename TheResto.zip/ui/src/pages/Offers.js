import React,{useEffect} from "react";
import aos from 'aos';
import 'aos/dist/aos.css';

function Offers(){
  useEffect(()=>{
    aos.init();
      },[])
    return(
        <>
         
         <div classNames="container-fluid" id="oHead">
         <h1 id="Offers" data-aos="fade-up" data-aos-duration="800" className="fs-1 text-center" >Offers</h1>
         </div>

         <br>
         </br>

         <button  className="btn btn-danger d-block mx-auto" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasBottom" aria-controls="offcanvasBottom">For FirstTime Users</button>

<div className="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasBottom" aria-labelledby="offcanvasBottomLabel">
  <div className="offcanvas-header d-flex ">
    <div id="t" >
    <h5 className="offcanvas-title text-center "  id="offcanvasBottomLabel">Special Offer For First Time Users</h5>
    </div>
    <div id="b">
    <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button></div>
  </div>
  <div id="bottom" className="offcanvas-body small">
  
  <div className="container-fluid  d-flex justify-content-center">
      <div data-aos="fade-up" data-aos-duration="800" id="oCard" className="card" >
     
      <div  className="card-body">
      <h5 className="card-title text-dark ">40% off upto Rs 500</h5>
        <p className="card-text text-dark text-center">      
        Code(#54GDEC)</p>                  
      </div>
    </div> 
  </div>
</div>
</div>

<br></br>

<div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
  <div data-aos="fade-right" data-aos-duration="1000" className="card" >
  <div id="O1" class="card-body">
    <p class="card-text">40% off on Veg Thali.</p>
  </div>
  </div>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-right" data-aos-duration="500" className="card" >
    <div id="O2" class="card-body">
    <p class="card-text">30% off on Sweets.</p>
  </div>
    </div>
    </div>
  
  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-left" data-aos-duration="500" className="card" >
    <div id="O3" class="card-body">
    <p class="card-text">40% off on Snacks.</p>
  </div>
    </div>
    </div>

    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 ">
      <div data-aos="fade-left" data-aos-duration="1000" className="card" >
      <div id="O4" class="card-body">
    <p class="card-text">50% off upto Rs 1000
    <br></br>(one time offer).</p>
  </div>
      </div>
      </div>


  </div>


  <div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
  <div data-aos="fade-right" data-aos-duration="1500" className="card" >
  <div id="O5" class="card-body">
    <p class="card-text">30% off on Ice creams.</p>
  </div>
  </div>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-right" data-aos-duration="700" className="card" >
    <div id="O6" class="card-body">
    <p class="card-text">20% off on South Indian dishes.</p>
  </div>
    </div>
    </div>
  
  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-left" data-aos-duration="700" className="card" >
    <div id="O7" class="card-body">
    <p class="card-text">50% off on Indian Bergers.</p>
  </div>
    </div>
    </div>

    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 ">
      <div data-aos="fade-left" data-aos-duration="1500" className="card" >
      <div id="O8" class="card-body">
    <p class="card-text">20% off on Fast Food</p>
  </div>
      </div>
      </div>


  </div>
  
        </>


    )
}
export default Offers;