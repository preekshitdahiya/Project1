import React from 'react';

export default function History()
{
    return(
        <>
        <div id="Hbox" className='card'>
            <img src="./images/no_history.png" className="img-fluid" alt='....'/>
             <p>No History yet</p>
        </div>
        </>
    )
}