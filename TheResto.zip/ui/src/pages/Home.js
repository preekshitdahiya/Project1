import React from 'react';
import Card from './Cards.js';


function Home(){

  

    return(  
      
<>

           <div id="carouselExampleAutoplaying" className="carousel slide" data-bs-ride="carousel">
    <div className="carousel-inner">
      <div  className="carousel-item active opacity-60">
        <img  src="https://cdn.pixabay.com/photo/2020/05/10/13/53/naan-5154130_960_720.jpg" className="d-block w-100" alt="..." />
        <div  className="carousel-caption d-none d-md-block ">
          <h5 >Finest Food</h5>
          <p >Best Indian food at your Service.</p>
        </div>
      </div>
      <div className="carousel-item opacity-60">
        <img src="https://cdn.pixabay.com/photo/2020/04/07/22/08/indian-food-5015066_640.jpg" className="d-block w-100" alt="..."/>
        <div  className="carousel-caption d-none d-md-block ">
          <h5 >Best Wraps</h5>
          <p >Western Versions Of Indian Food.</p>
        </div>

      </div>
      <div className="carousel-item opacity-60">
        <img src="https://cdn.pixabay.com/photo/2016/10/25/13/42/indian-1768906_640.jpg" className="d-block w-100" alt="..."/>
        <div  className="carousel-caption d-none d-md-block ">
          <h5 >Top Class Service</h5>
          <p >Best South Indian Dishes.</p>
        </div>
      </div>
    </div>
    <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
      <span className="carousel-control-prev-icon" aria-hidden="true"></span>
      <span className="visually-hidden">Previous</span>
    </button>
    <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
      <span className="carousel-control-next-icon" aria-hidden="true"></span>
      <span className="visually-hidden">Next</span>
    </button>
  </div>

        
        <div>
       
        <Card />

       
        </div>
          </>
    )
}
export default Home;