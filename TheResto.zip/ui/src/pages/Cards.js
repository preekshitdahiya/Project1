import React, { useEffect} from 'react';
import { Outlet,NavLink } from 'react-router-dom';
import aos from 'aos';
import 'aos/dist/aos.css';


function Card()
{
  useEffect(()=>{
aos.init();
  },[])

return(<>
   
    <div className="container-fluid mt-3 " id="cards">
       <p className="fs-1 text-center text-danger bg-light">OUR SPECIALITIES</p>
  <p data-aos="fade-up" className="text-center text-danger me-3">Try our special delicacies</p>

  <div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
  <div data-aos="fade-right" data-aos-duration="1000" className="card" >
    <img src="https://cdn.pixabay.com/photo/2012/07/09/07/16/thali-51996_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center ">Vegies</h5>
      <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      <NavLink to="#" className="btn btn-danger d-block mx-auto" >Order</NavLink>
    </div>
  </div>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-right" data-aos-duration="500" className="card" >
      <img  src="https://cdn.pixabay.com/photo/2019/03/22/18/25/food-4073884_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..." />
      <div className="card-body">
        <h5 className="card-title text-center">Indian Curry</h5>
        <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        <NavLink to="#" className="btn btn-danger d-block mx-auto" >Order</NavLink>
      </div>
    </div>
    </div>
  

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-left" data-aos-duration="500" className="card" >
      <img src="https://cdn.pixabay.com/photo/2017/09/09/12/09/india-2731817_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
      <div className="card-body">
        <h5 className="card-title text-center">Thali</h5>
        <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        <NavLink to="#" className="btn btn-danger d-block mx-auto">Order</NavLink>
      </div>
    </div>
    </div>

    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 ">
      <div data-aos="fade-left" data-aos-duration="1000" className="card" >
        <img src="https://cdn.pixabay.com/photo/2016/01/15/10/56/biryani-1141444_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
        <div className="card-body">
          <h5 className="card-title text-center">Veg Biryani</h5>
          <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <NavLink to="#" className="btn btn-danger d-block mx-auto">Order</NavLink>
        </div>
      </div>
      </div>


  </div>

  <div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
  <div data-aos="fade-right" data-aos-duration="1000" className="card" >
    <img src="https://cdn.pixabay.com/photo/2020/08/07/19/19/chili-chicken-5471407_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center">Chilli Potato</h5>
      <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      <NavLink to="#" className="btn btn-danger d-block mx-auto">Order</NavLink>
    </div>
  </div>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-right" data-aos-duration="500" className="card" >
      <img  src="https://cdn.pixabay.com/photo/2020/08/29/03/14/pokora-5526036_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..." />
      <div className="card-body">
        <h5 className="card-title text-center">Aloo Pakora</h5>
        <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        <NavLink to="#" className="btn btn-danger d-block mx-auto">Order</NavLink>
      </div>
    </div>
    </div>
  

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div data-aos="fade-left" data-aos-duration="500" className="card" >
      <img src="https://cdn.pixabay.com/photo/2024/02/17/01/45/ai-generated-8578594_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
      <div className="card-body">
        <h5 className="card-title text-center">Indian Samosa</h5>
        <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        <NavLink to="#" className="btn btn-danger d-block mx-auto">Order</NavLink>
      </div>
    </div>
    </div>

    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 ">
      <div data-aos="fade-left" data-aos-duration="1000" className="card" >
        <img src="https://cdn.pixabay.com/photo/2013/01/15/11/22/panipuri-74974_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
        <div className="card-body">
          <h5 className="card-title text-center">Panipuri</h5>
          <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          <NavLink to="#" className="btn btn-danger d-block mx-auto">Order</NavLink>
        </div>
      </div>
      </div>

<Outlet/>
  </div>
</div>

</>

    
)
}
export default Card;
