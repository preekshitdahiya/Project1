import React,{useEffect} from "react";
import aos from 'aos';
import 'aos/dist/aos.css';
function About(){
    useEffect(()=>{
        aos.init();
          },[])
    return(
        <>
        <div>
        <h1 data-aos="fade-down" data-aos-duration="1000" id="about_us_heading">About The Resto</h1>
       <section id="about_us">
      </section>
       <div id="About">
         <p>Hi, first of all, thanks for visiting this page. This page is all about The Resto. Read more for exciting things .</p>
         <p><b>Success is all about taking new initiatives. I started developing The Resto in the year 2022.</b>  </p> At the moment, I was providing training on Java. Meanwhile, I thought, why not to spread my knowledge to the world. So I started developing The Resto on Java using the Struts 2 framework. At that time, struts 2 was the leading web framework. I told one of my students to convert the Java programs into the HTML files. He converted all the files, I added some description about the page and put it on the website.<br/>
            After that, I added Spring and Hibernate and later I too many technologies. In 2013, I left the Job and set up a small business in Ghaziabad, and I hired some employees on content and training both. In 2 years, The Resto grew up from 1 to 10 employees. In 2015, I shifted my office location, Ghaziabad to Noida. In 4 years, I have achieved many things and learned a lot; and now the team size is 100+. So we are growing day by day. Our motto is to have 1000+ employees. Here, 70 employees are in content development and rest in Management, Development, Training and Digital Marketing.<br/>
           <b>Why I started the The Resto:</b> <br/>
           If you try to help others, God will help you surely. A student from another teacher came to me and said, Sir I asked for the slide (PPT) from the Sir (Don't want to mention any name) to my sir and he scolded me. I told him not to worry, we are nothing; we haven't made Java, we are just delivering the things in a better way, since I don't use any PPT, I will put all my notes on the web, you people can learn from there. It was just to help the students. I was unaware of any kind of business.<br/>
           <b>Why The Resto Name:</b><br/>
           I searched a lot of good names on the web, but all were registered. Since I was providing training in Mohan Nagar, Ghaziabad (Delhi/NCR), there was a tpoint which was very famous. So I just added tpoint with Java and checked on the net if it is registered or not. Thankfully, It was not registered. So, I registered this domain. In my opinion, name doesn't matter too much, work matters a lot. I thought, if I could work better to the existing site, it will be famous one day. And, thank God, now all the software professionals and students know about it.<br/>
           <b>Future Aspect:</b><br/>
           I always think: "It's just a beginning". I have to achieve more. I have the option to sell my website in 50 crores. But, I don't bound myself in 50 or 100 crores. I want to see my growth endless. It's not my dream to touch the sky, I want to go beyond the sky. Finally, I would like to say, It's just the beginning.<br/>
           <b>Belief in God:</b><br/>
           I have a strong belief in the existence of God. I think we are made of energy. One day, we will lose our energy (Aatma in Hindi), and it will go to the God again (Parmatma in Hindi).<br/>
           <b>About Success:</b><br/>
            Everybody has different thoughts on Success. What are the key points to get successful? Luck! May be but not all the time. There are a lot of factors that makes a person successful: positive thinking nature, your goal: you must know what do you have to do in life, decision-making ability, your working nature in setback and failures, time management: what are you doing now and what will you do in future, ready to take risks, and innovative ideas.<br/>
           <b>Being ideal defines your success.</b><br/>
      </div>

    </div>
        </>
    )
}
export default About;