import React,{useEffect,useState ,useRef} from "react";
import aos from 'aos';
import 'aos/dist/aos.css';
import { Outlet,NavLink } from 'react-router-dom';
import axios from 'axios';
import {useNavigate} from 'react-router-dom';

function Login(){
  useEffect(()=>{
    aos.init();
      },[])

      const [user,setUser]=useState();
      const [password,setPassword]=useState();
      const navigate=useNavigate();
      const fuser=useRef();
      const fpassword=useRef();


axios.defaults.withCredentials=true;
      const handleSubmit=(e)=>{
 e.preventDefault();
    axios.post('http://localhost:3001/login',{user,password})
        .then(result=> {console.log(result)
        if(result.data === "Success"){
          navigate('/')
          alert("Login successfully!");
        }
        else{
          alert(result.data);
        }
               
        })
        .catch(err=> console.log(err));

        

  
  fuser.current.value="";    
  fpassword.current.value="";
      }

  return(
    <>
    
    <nav className="navbar bg-body-tertiary ">
      <div className="container-fluid " >
      <div id="Card"  data-aos="zoom-in-up" data-aos-duration="500" className="card" >
      
      <div className="card-body d-block " >
       
        <h5 className="card-title text-white ">Best Food</h5>
        <p className="card-text text-white">One of the best Indian cuisines.</p>
    
        <button id="Button" className="navbar-toggler btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
        <p >Login</p>    
        </button>
          
      </div>
    </div> 
        
       
        <div className="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div className="offcanvas-header"> 
    
         
            
           
            <button type="button" className="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#my-offcanvas" aria-label="Close"></button>
          </div>
          
          <div className="offcanvas-body">
            <hr></hr>
          <h4 className="d-flex justify-content-center text-danger">Login</h4>
          <hr></hr>
          <br></br>

            <form id="login" className=" mt-3" onSubmit={handleSubmit}>
            <div className="col-12">
            <label for="validationDefault01" className="form-label">Username</label>
            <input className="form-control me-2" ref={fuser} id="validationDefault01" type="text" placeholder="Enter Username" onChange={(e)=>setUser(e.target.value)} required/><br></br>
            </div>
            <div className="col-12">
            <label for="validationDefault02" className="form-label">Password</label> 
            <input className="form-control me-2" ref={fpassword} id="validationDefault02" type="password" placeholder="Enter Password" onChange={(e)=>setPassword(e.target.value)} required/><br></br>
             </div>
              <button className="btn btn-outline-white btn-danger d-block mx-auto" type="submit">Continue</button>
              
            </form>
     <hr></hr>
            <p>Don't have account!Register first.</p>
            <NavLink to="/Register">Register</NavLink>
          </div>
          </div>
        </div>
     
    </nav>
<Outlet/>
    </>
    )
}
export default Login;