import React, { useEffect,useState } from 'react';
import {Outlet, NavLink } from 'react-router-dom';
import aos from 'aos'
import 'aos/dist/aos.css';
import axios from 'axios';


function Navbar(){
 
       const [user,setUser]=useState();
       const [auth,setAuth]=useState(false);
       const [message,setMessage]=useState();
       

       axios.defaults.withCredentials=true;
     useEffect(()=>{

      axios.get('http://localhost:3001/auth')
      .then(result => {
        if(result.data.Status === "Success")
           {
            setAuth(true);
           setUser(result.data.user);
          // console.log(auth)
           }

           else{
            setAuth(false);
            setMessage(result.data.Message);
        //  console.log(auth)
           }
      })
      aos.init();
     },[auth])

const handleLogout=()=>{
  axios.get('http://localhost:3001/logout')
  .then(res=>{
    if(res.data === "Success")
    {  setAuth(false);
    //  location.reload(true);
    }
    else{
      alert("error");
    }

  })
  .catch(err=>console.log(err));
}

    return(
        
        <nav id="navbar" data-aos="fade-down" data-aos-duration="1000" className="navbar navbar-expand-lg  sticky-top" >
        
        <img id="logo" className="border border-danger rounded-circle" alt='THE RESTO' src="./images/logo.jpg" />
      <NavLink id="head" className="navbar-brand text-danger fs-4 ms-2" to="/">THE RESTO</NavLink>

      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
          <li className="nav-item">
            <NavLink className="nav-link active " aria-current="page" to="/" >Home</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link active " to="/Menu" >Menu</NavLink>
          </li>

          <li className="nav-item">
            <NavLink className="nav-link active" to="/Offers" >Offers</NavLink>
          </li>
          
          <li className="nav-item">
            <NavLink className="nav-link active" to="/Login" >LogIn</NavLink>
          </li>
          {/* <li className="nav-item dropdown">
            <NavLink className="nav-link dropdown-toggle active "  role="button" data-bs-toggle="dropdown" aria-expanded="false">
             History
            </NavLink>
            <ul className="dropdown-menu">
              <li><NavLink className="dropdown-item" to="/History">Last week</NavLink></li>
              <li><NavLink className="dropdown-item" to="/History">This week</NavLink></li>
              <li><hr className="dropdown-divider"/></li>
              <li><NavLink className="dropdown-item" to="/History">Today</NavLink></li>          
             
            </ul>
          </li> */}
          
          <li className="nav-item">
            <NavLink className="nav-link active" to="/Contact" >Contact_us</NavLink>
          </li>

          <li className="nav-item">
            <NavLink className="nav-link active " to="/About" >About_us</NavLink>
          </li>
        </ul>

       { auth?
     
           <li className='me-3' id="logout">
           
           <div  className='me-4 mt-2'><p >{user}</p></div> 
          
            <div><button className='btn btn-danger' onClick={handleLogout}>Logout</button></div>
           </li>
          
         :
          <></>
          }           
        <form className="d-flex" role="search">
          <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
          <button className="btn btn-outline-success " type="submit" >Search</button>
        </form>
      </div>
   <Outlet/>
  </nav>

    )
}
export default Navbar;