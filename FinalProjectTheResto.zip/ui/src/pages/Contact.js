import React,{useEffect,useState,useRef} from "react";
import aos from 'aos';
import 'aos/dist/aos.css';
import axios from 'axios'

function Contact(){
  useEffect(()=>{
    aos.init();
      },[])

   
      const [email,setEmail]=useState();
      const [name,setName]=useState();
      const [subject,setSubject]=useState();
      const [message,setMessage]=useState();

   const femail=useRef();
   const fname=useRef();
   const fsubject=useRef();
   const fmessage=useRef();

       const handleSubmit=(e)=>{
        e.preventDefault();
        axios.post('http://localhost:3001/customer',{email,name,subject,message})
        .then(result=> console.log(result))
        .catch(err=> console.log(err));

        alert("Message sent successfully!");
  femail.current.value="";
  fname.current.value="";    
  fsubject.current.value="";
  fmessage.current.value="";     
       }

    return(
       <>
           

         <div className="container-fluid" id="Head">
  <h1 id="contact" data-aos="fade-up" data-aos-duration="1000" className="fs-1    text-center" >Contact Us</h1>
  </div>
<br></br>
  <div className="row">
    <div data-aos="fade-right" data-aos-duration="1000" className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
  <div id="cbox" className="card" >
    <img src="./images/address.png" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center text-info">Address</h5>
      <p className="card-text text-center">CGC College of Engineering<br/>
           Landran,Mohali<br/>
           Punjab,140307<br/>
           India
	  	</p>
      
    </div>
  </div>
  </div>

  <div data-aos="fade-right" data-aos-duration="500" className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div id="cbox"  className="card" >
      <img  src="./images/contact.png" className="card-img-top mx-auto rounded-circle mt-2" alt="..." />
      <div  className="card-body">
        <h5 className="card-title text-center text-info">Contact Number</h5>
        <p className="card-text text-center">+91-8218882128.</p>
        
      </div>
    </div>
    </div>
  

  <div data-aos="fade-left" data-aos-duration="500" className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3">
    <div  id="cbox" className="card" >
      <img src="./images/Email.png" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
      <div  className="card-body">
        <h5 className="card-title text-center text-info">Email</h5>
        <p className="card-text text-center">preekshitdahiyasaini@gmail.com</p>
        
      </div>
    </div>
    </div>

    <div data-aos="fade-left" data-aos-duration="1000" className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 ">
      <div id="cbox" className="card" >
        <img src="./images/website.png" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
        <div  className="card-body">
          <h5 className="card-title text-center text-info">Website</h5>
          <p className="card-text text-center">...</p>
          
        </div>
      </div>
      </div>
  </div>
<br></br>
  <div className="row">

    <div><h4 className='text-center'>For Contact</h4></div>
   <div className="col-3">
    
   </div>
   
   <div className="col-6">
    <form className="row g-3" onSubmit={handleSubmit}>
      <div className="col-md-12">
        <label for="validationDefault01" className="form-label">Email</label>
        <input type="email" ref={femail} className="form-control" id="validationDefault01" placeholder='Enter your email' onChange={(e)=>setEmail(e.target.value)} required/>
      </div>
      <div className="col-md-12">
        <label for="validationDefault02" className="form-label">Name</label>
        <input type="text" ref={fname} className="form-control" id="validationDefault02" placeholder='Enter your name' onChange={(e)=>setName(e.target.value)} required/>
      </div>
      <div className="col-12">
        <label for="validationDefault03" className="form-label">Subject</label>
        <input type="text" ref={fsubject} className="form-control" id="validationDefault03" placeholder='Enter subject of your message' onChange={(e)=>setSubject(e.target.value)} required/>
      </div>

      {/* <div className="col-12">
        <label for="inputAddress" className="form-label">Message</label>
        <input type="text" className="form-control" id="inputAddress" />
      </div> */}
       <div className="col-12">
     <label for="validationDefault04" class="form-label">Message</label>
      <textarea type="text"  ref={fmessage} className="form-control" id="validationDefault04" rows="3" placeholder='Enter your message' onChange={(e)=>setMessage(e.target.value)} required></textarea>
      </div>

      <div className="col-12">
        <button type="submit" className="btn btn-danger d-block mx-auto">Submit</button>
      </div>
    </form>
   </div>
   <div className="col-3"></div>
   </div> 
   
          
            </>
        )
    }

export default Contact;