import React,{useEffect} from "react";
import aos from 'aos';
import 'aos/dist/aos.css';

function Menu(){
  useEffect(()=>{
    aos.init();
      },[])
    return(
        <>
       <div classNameName="container-fluid" id="mHead">
  <h1 id="Menu" data-aos="fade-up" data-aos-duration="800" classNameName="fs-1    text-center" >Menu</h1>
  </div>

<div id="mcard" className="card-body  ">   
       
       
       <p data-aos="fade-up" data-aos-duration="1000" className="card-text text-danger">One of the best Indian cuisines.</p>

</div>

<div classNameName="container-fluid" id="menuh">
  <h1 id="Menu" classNameName="fs-1    text-center" >MAIN COURSE</h1>
  </div>


  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Meals</th>
      <th scope="col"></th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td colspan="2">DAL MAKHNI</td>
      <td>335/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PUNJABI DAL TADKA</td>
       <td>279/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PANEER BUTTER MASALA</td>
       <td>391/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">kADHAI PANEER</td>
      <td>391/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">MALAI KOFTA</td>
      <td>391/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">CORN CAPSICUM</td>
      <td>335/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">SARSON KA SAAG(SEASONAL)</td>
      <td>335/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PINDI CHANA</td>
      <td>391/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PANEER LABABDAR</td>
      <td>391/-</td>
    </tr>
  </tbody>
</table>



<div classNameName="container-fluid" id="menuh">
  <h1 id="Menu" classNameName="fs-1    text-center" >STAPLES</h1>
  </div>


  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Meals</th>
      <th scope="col"></th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PLAIN ROTI</td>
      <td>29/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">TANDORI ROTI</td>
       <td>35/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">BUTTER ROTI</td>
       <td>39/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PUDHINA ROTI</td>
      <td>39/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PLAIN NAAN</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">BUTTER NAAN</td>
      <td>65/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">GARLIC NAAN</td>
      <td>65/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PLAIN PRANTHA</td>
      <td>29/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">BUTTER PRANTHA</td>
      <td>39/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PANEER PRANTHA</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">ALOO PRANTHA</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PUDHINA PRANTHA</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PLAIN RICE</td>
      <td>223/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">JEERA RICE</td>
      <td>225/-</td>
    </tr>
   
  </tbody>
</table>



<div classNameName="container-fluid" id="menuh">
  <h1 id="Menu" classNameName="fs-1    text-center" >SNACKS</h1>
  </div>


  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Meals</th>
      <th scope="col"></th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td colspan="2">VADA PAV</td>
      <td>30/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">DAHIWADA</td>
       <td>40/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">VEG CUTLET</td>
       <td>40/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">SAMOSA</td>
      <td>20/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">VEG KABAB</td>
      <td>50/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">CHILLI POTATO</td>
      <td>50/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PAV BHAJI</td>
      <td>30/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">KANDA BHAJI</td>
      <td>30/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">ALOO PAKODA</td>
      <td>40/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">PANEER PAKODA</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">MISAL PAV</td>
      <td>50/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">MOONG PAKODA</td>
      <td>50/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">VEG SANDWICH</td>
      <td>43/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">VEG PRANTHA ROLLS</td>
      <td>50/-</td>
    </tr>
   

  </tbody>
</table>


<div classNameName="container-fluid" id="menuh">
  <h1 id="Menu" classNameName="fs-1    text-center" >SWEETS/DESSERTS</h1>
  </div>


  <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"></th>
      <th scope="col">Meals</th>
      <th scope="col"></th>
      <th scope="col">Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"></th>
      <td colspan="2">GULAB JAMUN</td>
      <td>60/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">RASGULLA</td>
       <td>54/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">RAJ BHOG</td>
       <td>90/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">RASMALAI</td>
      <td>90/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">MOONG DAL HALWA</td>
      <td>90/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">GAJAR HALWA</td>
      <td>90/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">KULFI</td>
      <td>65/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">ICE CREAM</td>
      <td>60/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">JALEBI</td>
      <td>50/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">IMARTI</td>
      <td>50/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">BARFI</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">BESAN KE LADOO</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">BONDI KE LADOO</td>
      <td>59/-</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td colspan="2">KAJU BARFI</td>
      <td>65/-</td>
    </tr>
   
  </tbody>
</table>
        </>
    )
}
export default Menu;