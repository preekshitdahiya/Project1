import React from 'react';
import {useNavigate} from "react-router-dom";

function Card({image,item})
{  
    const navigate=useNavigate();
   
     const goToOrder=()=>{    
          navigate("/Order",{state : {item :item}});
         }

    return(
     
         <div className="card">
            <img src={image} className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center ">{item}</h5>
      <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      <button onClick={goToOrder} className="btn btn-danger d-block mx-auto" >Order</button>
    </div>
 
         </div>
         
    )
}
export default Card;