import React, { useEffect, useState } from 'react';
import {useLocation} from 'react-router-dom';
import axios from 'axios';

function Order(){
    const location=useLocation();
    const item=location.state.item;
    const [price,setPrice]=useState();
   const Price=()=>{ 
    //   fetch('http://localhost:3001/price')
    //       .then(res=>res.json())
    //      .then((P) =>{           
    //                    setPrice(P)
    //                     })
    axios.post('http://localhost:3001/price',{item})
   .then((result)=> {
    setPrice(result.data)  
   })   
   .catch(err=> console.log(err));                  
   }

   const Send=()=>{
   axios.post('http://localhost:3001/order',{item})
   .then(result=> {console.log(result)
    if(result.data === "Success"){
           alert("Ordered successfully!");
    }
    if(result.data === "Login Now")
        {
            alert("Kindly Login first");
        }
   })
    .catch(err=> console.log(err));
   }

   useEffect(()=>{
    Price()
  
  })
    return(
      
        <>
       
         <div className="container " style={{border:"2px solid red",width:"30%",borderRadius:"5px",backgroundColor:"whitesmoke"}}>
                  <h2 style={{color:"red",textAlign:"center"}}>Order</h2>
            <hr></hr>
            
     <table className="table table-sm">
       <tbody>
      <tr >
      <th scope="row"></th>
      <td style={{color:"red"}}>Item</td>
      <td>:</td>
      <td>{item}</td>
       </tr>
       <br></br>
       <tr>
      <th scope="row"></th>
      <td style={{color:"red"}}>Price</td>
      <td>:</td>
      <td>{price}</td>
       </tr>
       </tbody>
        </table>

<button className='btn btn-danger d-block mx-auto mb-3' onClick={Send} >Order</button>
        </div>
        </>
    )
}
export default Order;