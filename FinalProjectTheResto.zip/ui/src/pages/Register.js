import React, { useState ,useRef} from "react";
import axios from 'axios';
import {useNavigate} from 'react-router-dom';

function Register(){

    const [user,setUser]=useState();
    const [email,setEmail]=useState();
    const [password,setPassword]=useState();
    const navigate=useNavigate();

    const femail=useRef();
    const fuser=useRef();
    const fpassword=useRef();

const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post('http://localhost:3001/register',{user,email,password})
        .then(result=> {console.log(result)
        navigate('/Login')
        
        })
        .catch(err=> console.log(err));

        alert("Registration successfully!");

  femail.current.value="";
  fuser.current.value="";    
  fpassword.current.value="";
 
}

    return(
        <>
        <div className="container" style={{border:"2px solid red",width:"30%",borderRadius:"5px",backgroundColor:"whitesmoke"}}>
        <form id="register" className=" mt-3" onSubmit={handleSubmit} >
            <h2 style={{color:"red",textAlign:"center"}}>Register</h2>
            <hr></hr>
            <div className="col-12">
            <label for="validationDefault01" className="form-label">Username</label>
            <input className="form-control me-2" ref={fuser} id="validationDefault01" type="text" placeholder="Enter Username" onChange={(e)=>setUser(e.target.value)} required/><br></br>
            </div>
            <div className="col-12">
            <label for="validationDefault02" className="form-label">Email</label> 
            <input className="form-control me-2" ref={femail} id="validationDefault02" type="email" placeholder="Enter Email" onChange={(e)=>setEmail(e.target.value)} required/><br></br>
             </div>
            <div className="col-12">
            <label for="validationDefault03" className="form-label">Password</label> 
            <input className="form-control me-2" ref={fpassword} id="validationDefault03" type="password" placeholder="Enter Password" onChange={(e)=>setPassword(e.target.value)} required/><br></br>
             </div>
              <button className="btn btn-outline-white btn-danger d-block mx-auto mb-3" type="submit">Register</button>
              
            </form>
        </div>
        </>
    )

}
export default Register;