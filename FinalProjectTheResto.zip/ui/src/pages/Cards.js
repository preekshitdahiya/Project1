import React, { useEffect} from 'react';

import aos from 'aos';
import 'aos/dist/aos.css';
import Card from './Card.js';
import Vegies from "./Vegies.jpg";
import Indian_Curry from "./Indian_Curry.jpg";
import Samosa from "./Samosa.jpg";
import Panipuri from "./panipuri.jpg";
import Pakora from "./pokora.jpg";
import Thali from "./thali.jpg";
import Chilli_potato from "./chilli_potato.jpg";
import Veg_biryani from "./biryani.jpg";

function Cards()
{
  useEffect(()=>{
aos.init();
  },[])

return(<>
   
    <div className="container-fluid mt-3 " id="cards">
       <p className="fs-1 text-center text-danger bg-light">OUR SPECIALITIES</p>
  <p data-aos="fade-up" className="text-center text-danger me-3">Try our special delicacies</p>

  <div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 " data-aos="fade-right" data-aos-duration="1000">
  {/* <div  className="card" >
     <img src="https://cdn.pixabay.com/photo/2012/07/09/07/16/thali-51996_640.jpg" className="card-img-top mx-auto rounded-circle mt-2" alt="..."  />
    <div className="card-body">
      <h5 className="card-title text-center ">Vegies</h5>
      <p className="card-text text-center">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
      <NavLink to="#" className="btn btn-danger d-block mx-auto" >Order</NavLink>
    </div> 
    
  </div> */}
  <Card image={Vegies} item={"Vegies"}/>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3" data-aos="fade-right" data-aos-duration="500">
        <Card image={Indian_Curry} item={"Indian Curry"}/>
    </div>
  

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3" data-aos="fade-left" data-aos-duration="500">
       <Card image={Thali} item={"Thali"}/>
    </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 " data-aos="fade-left" data-aos-duration="1000">
       <Card image={Veg_biryani} item={"Veg Biryani"}/>
      </div>


  </div>

  <div className="row">
    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3" data-aos="fade-right" data-aos-duration="1000">
    <Card image={Chilli_potato} item={"Chilli Potato"}/>
  </div>

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3" data-aos="fade-right" data-aos-duration="500">
       <Card image={Pakora} item={"Aloo pakora"}/>
    </div>
  

  <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3" data-aos="fade-left" data-aos-duration="500">
        <Card image={Samosa} item={"Indian Samosa"}/>
    </div>

    <div className="col-12 col-lg-3 col-md-6 d-flex justify-content-center mb-3 " data-aos="fade-left" data-aos-duration="1000">
           <Card image={Panipuri} item={"Panipuri"}/>
      </div>

      
  </div>
</div>

</>

    
)
}
export default Cards;
