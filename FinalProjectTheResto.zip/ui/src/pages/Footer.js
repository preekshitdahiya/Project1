import React, { useEffect ,useState,useRef} from 'react';
import { Outlet,NavLink } from 'react-router-dom';
import aos from 'aos'
import 'aos/dist/aos.css';
import axios from 'axios';

function Footer() {
	useEffect(()=>{
		aos.init();
		  },[])
		  const [feed,setFeed]=useState();
const newfeed=useRef();

const handleArrow=(e)=>{
	e.preventDefault();
	axios.post('http://localhost:3001/feedback',{feed})
	.then(result=> console.log(result))
	.catch(err=> console.log(err));

	newfeed.current.value="";
}


    return(
		
        
<footer data-aos="fade-up" data-aos-duration="1000">
    	<div id="row1" className='row container-fluid '>
	  <div className="col-12 col-lg-3 col-md-6 mb-3 mx-auto ">
		
		<h2 id="head" >The Resto</h2>
        <h2>Preekshit Dahiya</h2>
		<p>Contact For More Details and Feedback<br/>
		 Copyright &copy;The Resto<br/>
		All rights reserved!</p>
	  </div>
	  <div id="col" className="col-12 col-lg-3 col-md-6  mb-3 mx-auto">
	  	<h2 >Address:</h2>
	  	<p>CGC College of Engineering<br/>
           Landran,Mohali<br/>
           Punjab,140307<br/>
           India
	  	</p>
	  	<p id="email">preekshitdahiyasaini@gmail.com</p>
	  	<h3>+91-8218882128</h3>
	  </div>
	  <div id="col" className="col-12 col-lg-3 col-md-6  mb-3 mx-auto">
	  	<h2 >Links:</h2>
	  	<ul>
		         <li className="links"><NavLink className="nav-link" to="/">Home</NavLink></li>
                 <li className="links"><NavLink className="nav-link" to="/Menu">Menu</NavLink></li>
                 <li className="links"><NavLink className="nav-link" to="/Offers">Offers</NavLink></li>
				 <li className="links"><NavLink className="nav-link" to="/Login">Login</NavLink></li>			             
                 <li className="links"><NavLink className="nav-link" to="/Contact">Contact_us</NavLink></li>
                 <li className="links"><NavLink className="nav-link" to="/About">About_us</NavLink></li> 
	  	</ul>
	  </div>
	  <div id="col" className="col-12 col-lg-3 col-md-6  mb-3 mx-auto">
	  	<h2 >Message:</h2>
	  	<form id="footer_form" onSubmit={handleArrow} >
	  		<img id="envelope" src="./images/envelope.png"   alt='....envelope' />
	  		<input type="text" ref={newfeed} placeholder="Enter your Feedback" onChange={(e)=>setFeed(e.target.value)} required/>
	  		<button type="submit"><img id="arrow" src="./images/arrow.jpg" alt='....arrow' /></button>
	  	</form>
             
	  </div>
    </div>
	<Outlet/>
</footer>

    )
   
}
export default Footer;