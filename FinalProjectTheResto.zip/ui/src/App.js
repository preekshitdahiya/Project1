import React from 'react';
import Home from './pages/Home.js'
import Navbar from './pages/Navbar.js'
import Menu from './pages/Menu.js'
import Offers from './pages/Offers.js'
import Contact from './pages/Contact.js'
import About from './pages/About.js'
import Login from './pages/Login.js'
import Footer from './pages/Footer.js'
import Order from './pages/Order.js'
import { Routes,Route} from 'react-router-dom';
import Register from './pages/Register.js'

function App(){

      return( 
        <div > 
        <Navbar/>
           <Routes>
        
           <Route path="/" element={<Home/>}/> 
                      
           <Route path="/Menu" element={<Menu/>}/> 
           <Route path="/Offers" element={<Offers/>}/> 
           <Route path="/Login" element={<Login/>}/> 
           <Route path="/Order" element={<Order/>}/>
           <Route path="/Contact" element={<Contact/>}/> 
           <Route path="/About" element={<About/>}/>
           <Route path="/Register" element={<Register/>}/> 
           
           </Routes>
       <Footer/>   
           
         
      </div>

)
}
export default App;
