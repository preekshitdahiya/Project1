const mongoose=require("mongoose");
const orderSchema=mongoose.Schema({
   item:String,
   price:String,
   user:String
})

const orderModel=mongoose.model("orders",orderSchema)

module.exports=orderModel;