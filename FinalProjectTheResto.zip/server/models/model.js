const mongoose=require("mongoose");
const customerSchema=mongoose.Schema({
    email:String,
    name:String,
    subject:String,
    message:String
})

const customerModel=mongoose.model("customers",customerSchema)

module.exports=customerModel;