const mongoose=require("mongoose");
const menuSchema=mongoose.Schema({
   item:String,
   price:String,
})

const menuModel=mongoose.model("menus",menuSchema)

module.exports=menuModel;