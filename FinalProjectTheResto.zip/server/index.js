const express=require('express');
const mongoose=require("mongoose");
const cors=require("cors");
const jwt=require('jsonwebtoken');
const cookieParser=require('cookie-parser');
const bcrypt= require("bcrypt");

const app=express();
const customerModel=require('./models/model')
const feedModel=require('./models/feed')
// const addModel=require('./models/add')
const registerModel=require('./models/register')
const orderModel=require('./models/order');
const menuModel = require('./models/menu');
app.use(express.json());
app.use(cors(
    {
    origin:["http://localhost:3000"],
    methods:["GET","POST"],
    credentials:true
}
));
app.use(cookieParser());

mongoose.connect("mongodb://localhost:27017/TheResto");

app.post('/price',async(req,res)=>{
    const {item}=req.body;
    let {price}=await menuModel.findOne({"item":item})
      
    res.json(price)

})

app.post('/customer',(req,res)=>{
customerModel.create(req.body)
.then(customers=> res.json(customers))
.catch(err=>res.json(err))
})

app.post('/feedback',(req,res)=>{
    const m=req.body
   // console.log(m)
    feedModel.create(m)
    .then(feed=> res.json(feed))
    .catch(err=>res.json(err))
    })

app.post('/register',(req,res)=>{
    const {user,email,password}=req.body;
    bcrypt.hash(password,10)
    .then(hash=>{
        registerModel.create({user,email,password:hash})
        .then(register=> res.json(register))
        .catch(err=>res.json(err))
    }).catch(err=>console.log(err.message))
       
        })

app.post('/login',(req,res)=>{
           const {user,password}= req.body;
           registerModel.findOne({user:user})
           .then(users=>{        
            if(users){
                bcrypt.compare(password, users.password,(err,response) =>{
                     if (response)
                       {                        
                        const token=jwt.sign({user:users.user},"jwt-secret-key",{expiresIn:"1d"})
                        res.cookie('token',token)
                        res.json("Success")
                       } 
                     else{
                        res.json("The password is incorrect")
                     }  
                })
            }
            else{
                res.json("No record exists")
            }
         })
       })   


       const verifyUser=(req,res,next)=>{
   
        const token=req.cookies.token;
        if(!token)
            {
              return  res.json({Message:"Login Now"})
            }
         else{
            jwt.verify(token,"jwt-secret-key",(err,decoded)=>{
                if(err)
                    {
                      return  res.json({Message:"Authentication Error"})
                    }
                 else{
                    req.user=decoded.user;
                    next();
                 }   
            })
         }   
    }

app.get('/auth',verifyUser,(req,res)=>{

        return res.json({Status:"Success",user:req.user});
})

app.get('/logout',(req,res)=>{
    res.clearCookie('token');
    res.json("Success");
})


app.post("/order",async(req,res)=>{
    const {item}=req.body;
  
    let user="";
    let {price}=await menuModel.findOne({"item":item})
    // console.log(price)
       const token=req.cookies.token;
          if(!token)
             {
              return  res.json("Login Now")
             }
          else{
             jwt.verify(token,"jwt-secret-key",(err,decoded)=>{
                 if(err)
                    {
                      return  res.json({Message:"Authentication Error"})
                    }
                 else{
                   user=decoded.user;                  
                 }   
                })          
           
            orderModel.create({item,price,user})
             res.json("Success")
         }   
})


app.listen(3001,()=>{
    console.log("Server is running at 3001");
})